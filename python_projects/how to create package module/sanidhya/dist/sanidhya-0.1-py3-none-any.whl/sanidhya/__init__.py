def fun(number):
    print("function is running")
    return number
