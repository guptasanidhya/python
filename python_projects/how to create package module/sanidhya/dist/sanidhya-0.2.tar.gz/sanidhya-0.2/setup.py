from setuptools import setup
setup(name="sanidhya",
      version="0.2",
      description="this is description",
      long_description="this is very long description",
      author="sanidhya",
      packages=['sanidhya'],
      install_requires=[])