#without class
# def fun(number):
#     print("function is running")
#     return number

class add:
    def __init__(self):
        print("constructer chal raha hai")
    def fun(self,number):
     print("function is running")
     return number

