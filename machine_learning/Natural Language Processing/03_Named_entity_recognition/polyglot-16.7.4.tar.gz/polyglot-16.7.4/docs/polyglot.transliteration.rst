polyglot.transliteration package
================================

Subpackages
-----------

.. toctree::

    polyglot.transliteration.tests

Submodules
----------

polyglot.transliteration.base module
------------------------------------

.. automodule:: polyglot.transliteration.base
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: polyglot.transliteration
    :members:
    :undoc-members:
    :show-inheritance:
