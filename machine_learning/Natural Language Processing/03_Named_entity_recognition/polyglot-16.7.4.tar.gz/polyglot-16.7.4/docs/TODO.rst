
Tasks
=====

-  [STRIKEOUT:POS]
-  [STRIKEOUT:morphological analysis]
-  [STRIKEOUT:transliteration]

Library Interface
=================

-  [STRIKEOUT:Sentiment]
-  [STRIKEOUT:NER]
-  Frequency based comparison

Command Line interface
======================

-  Sentiment
-  Reading stdin column format

Infrastructure
==============

-  [STRIKEOUT:Cache models]
-  [STRIKEOUT:Add normalization to the embeddings]
-  [STRIKEOUT:Detect supported languages]
-  [STRIKEOUT:added task/lang as part of the identifier, what is left is
   to iterate over the collections.]
-  [STRIKEOUT:Throw different exception for missing package than
   undownloaded one]
-  [STRIKEOUT:Define NotSupportedLanguage/Task Exception for the
   downloader]
-  [STRIKEOUT:Remove noun phrases support.]
-  [STRIKEOUT:Train more/new POS taggers]

Documentation
=============

-  Add a quick tutorial
-  Embed demos in our documentation
-  [STRIKEOUT:pycld2 README]
-  [STRIKEOUT:Update rtdcs with the new submodules.]
