========
Usage
========

To use polyglot in a project::

	import polyglot